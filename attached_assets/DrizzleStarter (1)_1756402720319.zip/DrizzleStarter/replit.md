# Overview

This is a full-stack TypeScript web application built with React on the frontend and Express.js on the backend. The application provides user authentication and management functionality with a modern, responsive dashboard interface. It uses PostgreSQL as the database with Drizzle ORM for type-safe database operations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent UI components
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **Form Handling**: React Hook Form with Zod schema validation for type-safe forms
- **UI Components**: Comprehensive component library using Radix UI primitives with custom styling

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM for type-safe database operations and migrations
- **Authentication**: JWT-based authentication with session management
- **Password Security**: bcrypt for password hashing
- **API Structure**: RESTful API with middleware-based request handling
- **Development**: Hot module replacement via Vite integration for seamless development experience

## Database Schema
- **Users Table**: Stores user credentials, profile information, and account status
- **Sessions Table**: Manages user authentication sessions with token-based expiration
- **Database**: PostgreSQL with connection pooling and environment-based configuration

## Authentication & Authorization
- **Strategy**: JWT tokens with session validation
- **Password Storage**: Salted and hashed using bcrypt
- **Session Management**: Database-backed sessions with automatic cleanup
- **Authorization**: Middleware-based route protection with user context injection

## Development & Build Process
- **Development**: Vite dev server with Express backend proxy
- **Build**: Separate client and server builds with ESM modules
- **Database Migrations**: Drizzle Kit for schema management and migrations
- **TypeScript**: Strict type checking across the entire application stack

# External Dependencies

## Database
- **Neon Database**: PostgreSQL-compatible serverless database (@neondatabase/serverless)
- **Connection**: Environment variable-based DATABASE_URL configuration

## UI & Styling
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Radix UI**: Unstyled, accessible component primitives
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library with customizable styling

## Development Tools
- **Vite**: Build tool and development server with hot reload
- **Drizzle Kit**: Database schema management and migration tool
- **TypeScript**: Type safety across frontend, backend, and shared schemas

## Authentication Libraries
- **jsonwebtoken**: JWT token generation and validation
- **bcrypt**: Password hashing and verification

## Additional Services
- **Replit Integration**: Development environment integration with runtime error handling and cartographer support for enhanced debugging